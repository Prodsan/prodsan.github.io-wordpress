<?php


class AmazonAutoLinks_Proxy_Fetch_http extends AmazonAutoLinks_Proxy_Fetch_Base {

    protected $_sURL = 'https://www.proxy-list.download/api/v1/get?type=http';
    protected $_sScheme = 'http://';

}