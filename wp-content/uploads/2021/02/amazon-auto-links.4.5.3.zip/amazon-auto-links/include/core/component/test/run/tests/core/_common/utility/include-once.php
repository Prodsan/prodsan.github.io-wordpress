<?php
// This is for a test to include.
return 'foo';